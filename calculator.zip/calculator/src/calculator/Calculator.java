/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator {
    private JFrame frame;
    private JTextField displayField;
    private double currentResult = 0;
    private String currentInput = "";
    private String currentOperator = "";

    public Calculator() {
        frame = new JFrame("Simple Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);
        frame.setLayout(new BorderLayout());

        displayField = new JTextField();
        displayField.setEditable(false);
        frame.add(displayField, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 4));

        String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+"
        };

        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.addActionListener(new ButtonClickListener());
            buttonPanel.add(button);
        }

        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String actionCommand = e.getActionCommand();

            if (actionCommand.matches("[0-9]")) {
                currentInput += actionCommand;
                displayField.setText(currentInput);
            } else if ("C".equals(actionCommand)) {
                currentInput = "";
                currentResult = 0;
                currentOperator = "";
                displayField.setText("");
            } else if ("+-*/".contains(actionCommand)) {
                if (!currentInput.isEmpty()) {
                    if (!currentOperator.isEmpty()) {
                        calculateResult();
                    }
                    currentResult = Double.parseDouble(currentInput);
                    currentOperator = actionCommand;
                    currentInput = "";
                    displayField.setText("");
                }
            } else if ("=".equals(actionCommand)) {
                if (!currentOperator.isEmpty() && !currentInput.isEmpty()) {
                    calculateResult();
                    displayField.setText(String.valueOf(currentResult));
                }
            }
        }

        private void calculateResult() {
            double inputValue = Double.parseDouble(currentInput);
            switch (currentOperator) {
                case "+":
                    currentResult += inputValue;
                    break;
                case "-":
                    currentResult -= inputValue;
                    break;
                case "*":
                    currentResult *= inputValue;
                    break;
                case "/":
                    if (inputValue != 0) {
                        currentResult /= inputValue;
                    } else {
                        currentResult = 0; // Handle division by zero
                    }
                    break;
            }
            currentInput = "";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Calculator();
            }
        });
    }
}
