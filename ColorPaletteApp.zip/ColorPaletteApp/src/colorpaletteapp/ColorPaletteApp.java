/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colorpaletteapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ColorPaletteApp extends JFrame {
    private JPanel colorPanel;
    private JComboBox<String> colorComboBox;

    public ColorPaletteApp() {
        setTitle("Color Palette");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);

        // Create a panel for displaying the selected color
        colorPanel = new JPanel();
        colorPanel.setPreferredSize(new Dimension(200, 200));
        colorPanel.setBackground(Color.WHITE);

        // Create a combo box for color selection
        colorComboBox = new JComboBox<>(new String[]{"Red", "Green", "Blue", "Yellow", "White"});
        colorComboBox.setSelectedIndex(4); // Set the default color to White

        // Add an action listener to the combo box
        colorComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeBackgroundColor();
            }
        });

        // Create a panel for the combo box
        JPanel comboBoxPanel = new JPanel();
        comboBoxPanel.add(new JLabel("Select a color: "));
        comboBoxPanel.add(colorComboBox);

        // Add components to the frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(colorPanel, BorderLayout.CENTER);
        contentPane.add(comboBoxPanel, BorderLayout.SOUTH);
    }

    private void changeBackgroundColor() {
        String selectedColor = colorComboBox.getSelectedItem().toString();
        Color newColor;

        switch (selectedColor) {
            case "Red":
                newColor = Color.RED;
                break;
            case "Green":
                newColor = Color.GREEN;
                break;
            case "Blue":
                newColor = Color.BLUE;
                break;
            case "Yellow":
                newColor = Color.YELLOW;
                break;
            case "White":
                newColor = Color.WHITE;
                break;
            default:
                newColor = Color.WHITE; // Default to white
        }

        colorPanel.setBackground(newColor);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ColorPaletteApp app = new ColorPaletteApp();
            app.setVisible(true);
        });
    }
}
