/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temperatureconverterapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TemperatureConverterApp extends JFrame {
    private JTextField temperatureField = new JTextField(10);
    private JComboBox<String> sourceUnitBox = new JComboBox<>(new String[]{"Celsius", "Fahrenheit"});
    private JComboBox<String> targetUnitBox = new JComboBox<>(new String[]{"Celsius", "Fahrenheit"});
    private JButton convertButton = new JButton("Convert");
    private JLabel resultLabel = new JLabel("Result: ");

    public TemperatureConverterApp() {
        setTitle("Temperature Converter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        panel.add(new JLabel("Temperature: "));
        panel.add(temperatureField);
        panel.add(sourceUnitBox);
        panel.add(new JLabel("to"));
        panel.add(targetUnitBox);
        panel.add(convertButton);
        panel.add(resultLabel);

        convertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                convertTemperature();
            }
        });

        getContentPane().add(panel);
    }

    private void convertTemperature() {
        try {
            double temperature = Double.parseDouble(temperatureField.getText());
            String sourceUnit = sourceUnitBox.getSelectedItem().toString();
            String targetUnit = targetUnitBox.getSelectedItem().toString();
            double result = convert(temperature, sourceUnit, targetUnit);
            resultLabel.setText("Result: " + result + " " + targetUnit);
        } catch (NumberFormatException ex) {
            resultLabel.setText("Invalid input. Please enter a valid number.");
        }
    }

    private double convert(double temperature, String sourceUnit, String targetUnit) {
        if (sourceUnit.equals("Celsius") && targetUnit.equals("Fahrenheit")) {
            return (temperature * 9 / 5) + 32;
        } else if (sourceUnit.equals("Fahrenheit") && targetUnit.equals("Celsius")) {
            return (temperature - 32) * 5 / 9;
        } else {
            return temperature; // No conversion needed
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TemperatureConverterApp app = new TemperatureConverterApp();
            app.setVisible(true);
        });
    }
}
