/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbarapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProgressBarApp extends JFrame {
    private JProgressBar progressBar;
    private JButton startButton;
    private JButton resetButton;
    private Timer timer;
    private int progressValue = 0;

    public ProgressBarApp() {
        setTitle("Progress Bar Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);

        // Create a progress bar with initial value 0 and maximum value 100
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);

        // Create a "Start" button
        startButton = new JButton("Start");
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startProgressBar();
            }
        });

        // Create a "Reset" button
        resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetProgressBar();
            }
        });

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startButton);
        buttonPanel.add(resetButton);

        // Add components to the frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(progressBar, BorderLayout.CENTER);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        // Create a timer to update the progress
        timer = new Timer(100, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateProgressBar();
            }
        });
    }

    private void startProgressBar() {
        // Start the timer to update the progress
        timer.start();
    }

    private void updateProgressBar() {
        if (progressValue < 100) {
            progressValue++;
            progressBar.setValue(progressValue);
        } else {
            timer.stop();
        }
    }

    private void resetProgressBar() {
        // Reset the progress bar to 0
        progressValue = 0;
        progressBar.setValue(0);
        // Stop the timer if running
        timer.stop();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProgressBarApp app = new ProgressBarApp();
            app.setVisible(true);
        });
    }
}

