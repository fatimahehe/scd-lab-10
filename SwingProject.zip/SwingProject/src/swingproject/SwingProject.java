package swingproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SwingProject {
    private int clickCount = 0;
    private JLabel clickCountLabel;

    public SwingProject() {
       
        JFrame frame = new JFrame("Click Counter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(new FlowLayout());

        // Create a JButton
        JButton clickButton = new JButton("Click Me!");

        // Create a JLabel to display the click count
        clickCountLabel = new JLabel("Click count: " + clickCount);

        // Add an ActionListener to the button
        clickButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Increment the click count and update the label
                clickCount++;
                clickCountLabel.setText("Click count: " + clickCount);
            }
        });

        // Add the button and label to the frame
        frame.add(clickButton);
        frame.add(clickCountLabel);

        // Make the frame visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SwingProject();
            }
        });
    }
}
