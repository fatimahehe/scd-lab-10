/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingprogram;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DrawingProgram extends JFrame {
    private JPanel drawingCanvas;
    private JButton lineButton;
    private JButton rectangleButton;
    private JButton ellipseButton;

    private int startX, startY;
    private int endX, endY;
    private Shape currentShape = null;

    public DrawingProgram() {
        setTitle("Simple Drawing Program");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        drawingCanvas = new JPanel();
        drawingCanvas.setBackground(Color.WHITE);

        lineButton = new JButton("Line");
        rectangleButton = new JButton("Rectangle");
        ellipseButton = new JButton("Ellipse");

        lineButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setCurrentShape(Shape.LINE);
            }
        });

        rectangleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setCurrentShape(Shape.RECTANGLE);
            }
        });

        ellipseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setCurrentShape(Shape.ELLIPSE);
            }
        });

        drawingCanvas.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                startX = e.getX();
                startY = e.getY();
            }

            public void mouseReleased(MouseEvent e) {
                endX = e.getX();
                endY = e.getY();
                drawShape(startX, startY, endX, endY);
            }
        });

        setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(lineButton);
        buttonPanel.add(rectangleButton);
        buttonPanel.add(ellipseButton);

        add(buttonPanel, BorderLayout.NORTH);
        add(drawingCanvas, BorderLayout.CENTER);
    }

    private void setCurrentShape(Shape shape) {
        currentShape = shape;
    }

    private void drawShape(int x1, int y1, int x2, int y2) {
        if (currentShape != null) {
            Graphics g = drawingCanvas.getGraphics();
            g.setColor(Color.BLACK);

            switch (currentShape) {
                case LINE:
                    g.drawLine(x1, y1, x2, y2);
                    break;
                case RECTANGLE:
                    g.drawRect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
                    break;
                case ELLIPSE:
                    g.drawOval(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
                    break;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DrawingProgram app = new DrawingProgram();
            app.setVisible(true);
        });
    }

    enum Shape {
        LINE, RECTANGLE, ELLIPSE
    }
}
