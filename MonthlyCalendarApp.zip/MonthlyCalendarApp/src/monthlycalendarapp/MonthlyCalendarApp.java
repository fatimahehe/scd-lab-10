/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monthlycalendarapp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MonthlyCalendarApp extends JFrame {
    private JTable calendarTable;
    private DefaultTableModel tableModel;
    private JTextArea eventTextArea;
    private JButton addEventButton;

    public MonthlyCalendarApp() {
        setTitle("Monthly Calendar");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
        setLocationRelativeTo(null);

        // Create a table model for the calendar
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        calendarTable = new JTable(tableModel);

        // Set the table to single selection mode
        calendarTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Create a scroll pane for the calendar
        JScrollPane calendarScrollPane = new JScrollPane(calendarTable);

        // Create a text area for event input
        eventTextArea = new JTextArea(5, 20);

        // Create a button to add events
        addEventButton = new JButton("Add Event");
        addEventButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEvent();
            }
        });

        // Create a panel for event input and the button
        JPanel eventPanel = new JPanel();
        eventPanel.add(new JLabel("Event:"));
        eventPanel.add(eventTextArea);
        eventPanel.add(addEventButton);

        // Add components to the frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(calendarScrollPane, BorderLayout.CENTER);
        contentPane.add(eventPanel, BorderLayout.SOUTH);

        initializeCalendar();
    }

    private void initializeCalendar() {
        Calendar today = Calendar.getInstance();
        int currentYear = today.get(Calendar.YEAR);
        int currentMonth = today.get(Calendar.MONTH);

        today.set(currentYear, currentMonth, 1);
        int firstDayOfMonth = today.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = today.getActualMaximum(Calendar.DAY_OF_MONTH);

        String[] columnNames = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

        // Set column names
        for (String day : columnNames) {
            tableModel.addColumn(day);
        }

        int day = 1;
        int row = 0;
        while (day <= daysInMonth) {
            for (int col = 0; col < 7; col++) {
                if (row == 0 && col < firstDayOfMonth - 1) {
                    // Fill empty cells in the first row
                    tableModel.addRow(new String[7]);
                } else if (day <= daysInMonth) {
                    tableModel.addRow(new String[7]);
                    tableModel.setValueAt(Integer.toString(day), row, col);
                    day++;
                }
            }
            row++;
        }
    }

    private void addEvent() {
        int selectedRow = calendarTable.getSelectedRow();
        int selectedColumn = calendarTable.getSelectedColumn();

        if (selectedRow >= 0 && selectedColumn >= 0) {
            String date = String.valueOf(tableModel.getValueAt(selectedRow, selectedColumn));
            String event = eventTextArea.getText();

            if (!event.isEmpty()) {
                String existingEvents = String.valueOf(tableModel.getValueAt(selectedRow, selectedColumn));
                if (existingEvents == null || existingEvents.isEmpty()) {
                    existingEvents = event;
                } else {
                    existingEvents += "\n" + event;
                }
                tableModel.setValueAt(existingEvents, selectedRow, selectedColumn);
                eventTextArea.setText("");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MonthlyCalendarApp app = new MonthlyCalendarApp();
            app.setVisible(true);
        });
    }
}
